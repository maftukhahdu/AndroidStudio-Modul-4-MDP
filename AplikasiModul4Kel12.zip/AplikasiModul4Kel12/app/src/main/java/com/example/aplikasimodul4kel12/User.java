package com.example.aplikasimodul4kel12;

public class User {
    int id;
    static String username;
    static String password;

    public User(){}

    public User(int id, String username, String password) {
        this.id = id;
        User.username = username;
        User.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        User.username = username;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        User.password = password;
    }
}
